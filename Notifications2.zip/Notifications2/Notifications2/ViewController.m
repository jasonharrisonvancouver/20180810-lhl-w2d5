//
//  ViewController.m
//  Notifications2
//
//  Created by steve on 2017-03-17.
//  Copyright © 2017 steve. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *xConstraint;
@end

@implementation ViewController

- (void)viewDidLoad {
  [super viewDidLoad];
  NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
  [center addObserver:self selector:@selector(keyboardUp:) name:UIKeyboardWillShowNotification object:nil];
}

- (void)keyboardUp:(NSNotification *)notification {
  
  NSValue *value = notification.userInfo[UIKeyboardFrameEndUserInfoKey];
  CGRect rect = [value CGRectValue];
  CGFloat height = rect.size.height;
  NSLog(@"%@", @(height));
//  CGFloat xConstant = self.xConstraint.constant;
//  xConstant -= height;
//  self.xConstraint.constant = xConstant;
  CGRect bounds = self.view.bounds;
  CGFloat yOrigin = bounds.origin.y;
  yOrigin += height;
  CGRect newBounds = CGRectMake(bounds.origin.x, yOrigin, bounds.size.width, bounds.size.height);
  self.view.bounds = newBounds;
}

- (void)dealloc {
  NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
  [center removeObserver:self];
}



@end
